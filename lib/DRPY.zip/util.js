var _mod = require("./mod.js");
var request_timeout = 5e3;
var http = function http(url) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.method === "POST" && options.data) {
    options.body = JSON.stringify(options.data);
    options.headers = Object.assign({
      "content-type": "application/json"
    }, options.headers);
  }
  options.timeout = request_timeout;
  try {
    var res = req(url, options);
    res.json = function () {
      try {
        print(res.content)
        return res && res.content ? JSON.parse(res.content) : null;
      } catch (e) {
        return null;
      }
    };
    res.text = function () {
      return res && res.content ? res.content : "";
    };
    return res;
  } catch (e) {
    return {
      json: function json() {
        return null;
      },
      text: function text() {
        return "";
      }
    };
  }
};
["get", "post"].forEach(function (method) {
  http[method] = function (url) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return http(url, Object.assign(options, {
      method: method.toUpperCase()
    }));
  };
});


function findBestLCS(mainItem, targetItems) {
  const results = [];
  let bestMatchIndex = 0;

  for (let i = 0; i < targetItems.length; i++) {
      const currentLCS = lcs(mainItem.name, targetItems[i].name);
      results.push({ target: targetItems[i], lcs: currentLCS });
      if (currentLCS.length > results[bestMatchIndex].lcs.length) {
          bestMatchIndex = i;
      }
  }

  const bestMatch = results[bestMatchIndex];

  return { allLCS: results, bestMatch: bestMatch, bestMatchIndex: bestMatchIndex };
}

function delay(ms) {
  const start = Date.now();
  while (Date.now() - start < ms) {}
  // return new Promise((resolve) => setTimeout(resolve, ms));
}

function showHUD(msg) {
  try {
    showHUD_b(msg);
  } catch (e) {
    print(e)
  }
}

function inputValue(key, describe) {
  try {
    inputValue_b(key, describe);
  } catch (e) {
    print(e)
  }
}

const localMap = new Map();
function getStorage(key) {
  try {
    return getStorage_b(key);
  } catch (e) {
    return localMap.get("ali", key);
    print(e)
  }
}

function setStorage(key, value) {
  try {
    setStorage_b(key, value);
  } catch (e) {
    localMap.set("ali", k, v);
    print(e)
  }
}

function getASToken() {
    try {
      return getASToken_b();
    } catch (e) {
      return "";
      print(e)
    }
}

function getStorageDic(key) {
  let valueStr = getStorage(key)
  if (valueStr) {
    let value = JSON.parse(valueStr);
    return value;
  }
  return null
}

function setDicStorage(key, value) {
  let valueStr = JSON.stringify(value);
  setStorage(key, valueStr);
}
function getBoolStorage(key) {
  let valueStr = getStorage(key)
  if (valueStr === "1") {
    return true;
  }
  return false
}
function setBoolStorage(key, value) {
  setStorage(key, (value ? "1" : "0"));
}

/**
 * 字符串相似度匹配
 * @returns
 */
function lcs(str1, str2) {
  if (!str1 || !str2) {
      return {
          length: 0,
          sequence: '',
          offset: 0,
      };
  }

  var sequence = '';
  var str1Length = str1.length;
  var str2Length = str2.length;
  var num = new Array(str1Length);
  var maxlen = 0;
  var lastSubsBegin = 0;

  for (var i = 0; i < str1Length; i++) {
      var subArray = new Array(str2Length);
      for (var j = 0; j < str2Length; j++) {
          subArray[j] = 0;
      }
      num[i] = subArray;
  }
  var thisSubsBegin = null;
  for (i = 0; i < str1Length; i++) {
      for (j = 0; j < str2Length; j++) {
          if (str1[i] !== str2[j]) {
              num[i][j] = 0;
          } else {
              if (i === 0 || j === 0) {
                  num[i][j] = 1;
              } else {
                  num[i][j] = 1 + num[i - 1][j - 1];
              }

              if (num[i][j] > maxlen) {
                  maxlen = num[i][j];
                  thisSubsBegin = i - num[i][j] + 1;
                  if (lastSubsBegin === thisSubsBegin) {
                      // if the current LCS is the same as the last time this block ran
                      sequence += str1[i];
                  } else {
                      // this block resets the string builder if a different LCS is found
                      lastSubsBegin = thisSubsBegin;
                      sequence = ''; // clear it
                      sequence += str1.substr(lastSubsBegin, i + 1 - lastSubsBegin);
                  }
              }
          }
      }
  }
  return {
      length: maxlen,
      sequence: sequence,
      offset: thisSubsBegin,
  };
}


function levenshteinDistance(str1, str2) {
  return 100 - 100 * (0, distance)(str1, str2) / Math.max(str1.length, str2.length);
}
function get_size(sz) {
  if (sz <= 0) {
    return "";
  }
  var filesize = "";
  if (sz > 1024 * 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024 * 1024;
    filesize = "TB";
  } else if (sz > 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024;
    filesize = "GB";
  } else if (sz > 1024 * 1024) {
    sz /= 1024 * 1024;
    filesize = "MB";
  } else if (sz > 1024) {
    sz /= 1024;
    filesize = "KB";
  } else {
    filesize = "B";
  }
  var sizeStr = sz.toFixed(2) + filesize,
    index = sizeStr.indexOf("."),
    dou = sizeStr.substr(index + 1, 2);
  if (dou === "00") {
    return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
  } else {
    return sizeStr;
  }
}


function hasChinese(text) {
  var reg = /[\u4e00-\u9fa5]/;
  return reg.test(text);
}

function episodeNameTrim(text) {
  var name = text.replace(/玩偶哥.*【神秘的哥哥们】/g, '');
    name = name.replace(/\.(?:mp4|avi|mkv)$/i, '');
  return name;
}

function decodeBase64(str) {
  var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  var output = "";
  var chr1, chr2, chr3;
  var enc1, enc2, enc3, enc4;
  var i = 0;

  str = str.replace(/[^A-Za-z0-9+/=]/g, "");

  while (i < str.length) {
      enc1 = keyStr.indexOf(str.charAt(i++));
      enc2 = keyStr.indexOf(str.charAt(i++));
      enc3 = keyStr.indexOf(str.charAt(i++));
      enc4 = keyStr.indexOf(str.charAt(i++));

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output += String.fromCharCode(chr1);

      if (enc3 !== 64) {
          output += String.fromCharCode(chr2);
      }
      if (enc4 !== 64) {
          output += String.fromCharCode(chr3);
      }
  }

  return output;
}

function encodeBase64(s) {
  const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let i;
  let d = s;
  let b = 0, b0, b1, b2;
  let bytes = [];
  
  // 将字符串转换为字节数组
  for (i = 0; i < d.length; i++) {
    bytes.push(d.charCodeAt(i));
  }
  d = bytes;
  
  let result = '';
  
  // 每三个字节一组进行编码
  for (i = 0; i < d.length; i += 3) {
    b0 = d[i];
    b1 = i + 1 < d.length ? d[i + 1] : 0;
    b2 = i + 2 < d.length ? d[i + 2] : 0;
    
    b = (b0 << 16) | (b1 << 8) | b2;
    
    result += keyStr[(b >> 18) & 0x3f];
    result += keyStr[(b >> 12) & 0x3f];
    result += i + 1 < d.length ? keyStr[(b >> 6) & 0x3f] : '=';
    result += i + 2 < d.length ? keyStr[b & 0x3f] : '=';
  }
  
  return result;
}

function isNewAPP() {
  try {
    getStorage_b("versions");
      return true
  } catch (e) {
      return false
  }
}
function getVersions() {
    try {
        return parseInt(getVersions_b());
    } catch (e) {
        return 1
    }
}

function generateUUID() {
    var chars = '0123456789abcdef';
    var uuid = '';
    for (var i = 0; i < 36; i++) {
        var char = '';
        if (i === 8 || i === 13 || i === 18 || i === 23) {
            char = '-';
        } else if (i === 14) {
            char = '4'; // UUID version 4
        } else if (i === 19) {
            char = chars.substr(Math.floor(Math.random() * 4) + 8, 1); // 8, 9, a, or b
        } else {
            char = chars.substr(Math.floor(Math.random() * 16), 1);
        }
        uuid += char;
    }
    return uuid;
}

function sortListByName(vodList, key, order) {
  if (!key) {
    return vodList;
  }
  order = order || "asc";
  return vodList.sort(naturalSort({
    key: key,
    order: order,
    caseSensitive: true
  }));
};

function naturalSort(options) {
  if (!options) {
    options = {};
  }
  return function (a, b) {
    if (options.key) {
      a = a[options.key];
      b = b[options.key];
    }
    var EQUAL = 0;
    var GREATER = options.order === "desc" ? -1 : 1;
    var SMALLER = -GREATER;
    var re = /(^-?[0-9]+(\.?[0-9]*)[df]?e?[0-9]?$|^0x[0-9a-f]+$|[0-9]+)/gi;
    var sre = /(^[ ]*|[ ]*$)/g;
    var dre = /(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/;
    var hre = /^0x[0-9a-f]+$/i;
    var ore = /^0/;
    var normalize = function normalize(value) {
      var string = "" + value;
      return options.caseSensitive ? string : string.toLowerCase();
    };
    var x = normalize(a).replace(sre, "") || "";
    var y = normalize(b).replace(sre, "") || "";
    var xN = x.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0");
    var yN = y.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0");
    if (!x && !y) return EQUAL;
    if (!x && y) return GREATER;
    if (x && !y) return SMALLER;
    var xD = parseInt(x.match(hre)) || xN.length != 1 && x.match(dre) && Date.parse(x);
    var yD = parseInt(y.match(hre)) || xD && y.match(dre) && Date.parse(y) || null;
    var oFxNcL, oFyNcL;
    if (yD) {
      if (xD < yD) return SMALLER;else if (xD > yD) return GREATER;
    }
    for (var cLoc = 0, numS = Math.max(xN.length, yN.length); cLoc < numS; cLoc++) {
      oFxNcL = !(xN[cLoc] || "").match(ore) && parseFloat(xN[cLoc]) || xN[cLoc] || 0;
      oFyNcL = !(yN[cLoc] || "").match(ore) && parseFloat(yN[cLoc]) || yN[cLoc] || 0;
      if (isNaN(oFxNcL) !== isNaN(oFyNcL)) return isNaN(oFxNcL) ? GREATER : SMALLER;else if (_typeof(oFxNcL) !== _typeof(oFyNcL)) {
        oFxNcL += "";
        oFyNcL += "";
      }
      if (oFxNcL < oFyNcL) return SMALLER;
      if (oFxNcL > oFyNcL) return GREATER;
    }
    return EQUAL;
  };
}

function getUCShareData(url) {
    let regex = /https:\/\/drive\.uc\.cn\/s\/([^/?&]+)/;
    let matches = regex.exec(url);
    if (matches) {
      return {
        shareId: matches[1],
        folderId: '0',
      };
    }
    return null;
  }

function getPikpakShareData(url) {
  let shareIdRegex = /https:\/\/pikpak\.com\/share\/s\/([^?&]+)/;
  let passwordRegex = /[?&]password=([^&]+)/;

  let shareIdMatches = shareIdRegex.exec(url);
  let passwordMatches = passwordRegex.exec(url);

  if (shareIdMatches) {
    return {
      shareId: shareIdMatches[1],
      password: passwordMatches ? passwordMatches[1] : null,
    folderId: '0',
    };
  }
  return null;
}

function formatPlayUrl(src, name) {
  if (src.trim() == name.trim()) {
      return name;
  }
  return name
      .trim()
      .replaceAll(src, '')
      .replace(/<|>|《|》/g, '')
      .replace(/\$|#/g, ' ')
      .trim();
}

function getCookies(cookieString, domain) {

  var cookieStr = cookieString.replace(/; Expires=[^;]+GMT/g, '');
  cookieStr = cookieStr.replace(/; expires=[^;]+GMT/g, '');
  // 分割 Cookie 字符串成单独的键值对
  var cookies = cookieStr.split(', ');

  // 存储符合域名的 Cookie
  var domainCookies = [];

  // 遍历每个键值对
  for (var i = 0; i < cookies.length; i++) {
      // 解析键值对的名称和值
      var cookieParts = cookies[i].split('; ');
      var cookieNameValue = cookieParts[0].split('=');
      var cookieName = cookieNameValue[0];
      var cookieValue = cookieNameValue.length > 1 ? cookieNameValue[1] : '';

      // 检查是否符合传入的域名
      var cookieDomain = cookieParts.find(part => part.toLowerCase().startsWith('domain='));
      if (cookieDomain) {
        if (cookieDomain.split('=')[1].includes(domain)) {
            if (cookieValue) {
                domainCookies.push(cookieName + '=' + cookieValue);
            }
        }
      }else{
          if (cookieValue) {
              domainCookies.push(cookieName + '=' + cookieValue);
          }
      }
  }
  return domainCookies.join('; ');
}
